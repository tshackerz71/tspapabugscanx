package main

import (
	"github.com/ayanrajpoot10/bugscanx-go/cmd"
)

func main() {
	cmd.Execute()
}
